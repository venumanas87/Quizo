package com.quizo;

import android.view.View;

public interface CustomStoryClick {
    public void onItemClick(View v, int position);
}
