package com.quizo;

import androidx.appcompat.app.AppCompatActivity;

public class StoryActivity extends AppCompatActivity {
}
