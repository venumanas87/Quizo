package com.quizo;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.adcolony.sdk.AdColony;
import com.adcolony.sdk.AdColonyAdSize;
import com.adcolony.sdk.AdColonyAdView;
import com.adcolony.sdk.AdColonyAdViewListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomnavigation.LabelVisibilityMode;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;


public class OffActivity extends AppCompatActivity {
    private static final String APP_ID = "app40514ed2b6b44d8ab8" ;
    private static final String ZONE_IDS = "vzf0e127cae4794498ab";
    RecyclerView recyclerView;
    MaterialButton btn;
    NewsAdapter newsAdapter;
    TextView tv;
    List<NewsData> newsDataList;
    BottomNavigationView bottomNavigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AdColony.configure(this, APP_ID, ZONE_IDS);
        AdColonyAdViewListener listener = new AdColonyAdViewListener() {
            @Override
            public void onRequestFilled(AdColonyAdView ad) {
                /** Add this ad object to whatever layout you have set up for this placement */
            }
        };

        AdColony.requestAdView(ZONE_IDS, listener, AdColonyAdSize.BANNER);
        setContentView(R.layout.activity_off);
         recyclerView = findViewById(R.id.recycler_view);
         btn = findViewById(R.id.but);
         tv=findViewById(R.id.emp);
        bottomNavigationView = findViewById(R.id.btmnav);
        bottomNavigationView.setLabelVisibilityMode(LabelVisibilityMode.LABEL_VISIBILITY_UNLABELED);
        bottomNavigationView.setSelectedItemId(R.id.page_3);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.page_2 :
                        startActivity(new Intent(getApplicationContext(),NewsActivity.class));
                        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
                        return true;
                    case R.id.page_1 :
                        startActivity(new Intent(getApplicationContext(),LoggedIn.class));
                        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
                    case R.id.page_3 :
                       return  true;


                }

                return false;
            }
        });
        newsDataList = new ArrayList<>();
        NewsData data;
        newsAdapter = new NewsAdapter(newsDataList, new CustomStoryClick() {
            @Override
            public void onItemClick(View v, int position) {

            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        DboffHelper helper = new DboffHelper(getApplicationContext());
                        SQLiteDatabase db = helper.getWritableDatabase();
                        db.delete("NEWS",null,null);
                        newsDataList.clear();
                        newsAdapter.notifyDataSetChanged();
                        ch();
                    }
                });

            }
        });

        RecyclerView.LayoutManager layoutManager1 = new LinearLayoutManager(getApplicationContext(), RecyclerView.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager1);
        recyclerView.setAdapter(newsAdapter);
        DboffHelper helper = new DboffHelper(this);
        SQLiteDatabase database = helper.getWritableDatabase();
        Cursor cursor = database.rawQuery("SELECT DISTINCT TITLE,DESCRIPTION,AUTHOR,DATE,IMAGEURL FROM NEWS",new String[]{});
        if(cursor != null && cursor.moveToFirst()){

            do {
                String title = cursor.getString(0);
                String description = cursor.getString(1);
                String author = cursor.getString(2);
                String date = cursor.getString(3);
                String url = cursor.getString(4);
                data = new NewsData(title,"desc",date,author,url,description,"second",0);
                newsDataList.add(data);
            }while (cursor.moveToNext());
        }

        newsAdapter.notifyDataSetChanged();
        ch();
    }

    private void ch() {
        if(newsDataList.size()==0){
            tv.setVisibility(View.VISIBLE);
            btn.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        bottomNavigationView.setSelectedItemId(R.id.page_3);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
    }
}
