package com.quizo

import android.os.Bundle
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.squareup.picasso.Picasso
import jp.wasabeef.picasso.transformations.BlurTransformation

class StoryView : AppCompatActivity() {
    var bgblur: ImageView? = null
    var imgcon: ImageView? = null
    var back: ImageView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.story_view)
        var title: TextView? = findViewById(R.id.stit)
        bgblur = findViewById(R.id.imgblur)
        imgcon = findViewById(R.id.image)
        back = findViewById(R.id.back)
        val rl = findViewById<RelativeLayout>(R.id.rl1)
        var titles: String? = null
        var imgurl: String? = null
        val extras = intent.extras
        if (extras != null) {
            titles = extras.getString("title")
            imgurl = extras.getString("url")
        }
            title?.setText(titles)
        Picasso.get().load(imgurl).transform(BlurTransformation(applicationContext)).fit().into(bgblur)
        Picasso.get().load(imgurl).fit().into(imgcon)
    }
}