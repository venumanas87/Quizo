package com.quizo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.MyViewHolder> {
    private List<CoData> dataList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView curr, act, dea, rec, conf;

        public  MyViewHolder(View view){
super(view);
            curr=view.findViewById(R.id.inyour2);
            act = view.findViewById(R.id.act2);
            dea = view.findViewById(R.id.dea2);
            rec = view.findViewById(R.id.rec2);
            conf = view.findViewById(R.id.conf2);

        }

    }
    public DataAdapter(List<CoData> dataList){
        this.dataList=dataList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.card_re, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            CoData data = dataList.get(position);
            holder.act.setText(data.getActive());
            holder.conf.setText(data.getConfirmed());
            holder.curr.setText(data.getCurrently());
            holder.dea.setText(data.getDeaths());
            holder.rec.setText(data.getRecovered());
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }
}
