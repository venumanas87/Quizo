package com.quizo;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.jaeger.library.StatusBarUtil;

public class MainActivity extends AppCompatActivity {
    LottieAnimationView monkey;
    MaterialButton getstarted;
    CountDownTimer count;
    View view;
    public void checkNetworkConnection() {
        Snackbar.make(view,"Please Connect to internet", BaseTransientBottomBar.LENGTH_INDEFINITE);
    }

    public void isNetworkConnectionAvailable() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnected();
        if (isConnected) {
            Only();
            Log.d("Network", "Connected");
        } else {
            checkNetworkConnection();
            Log.d("Network", "Not Connected");
            monkey.setAnimation(R.raw.nointernet);
            monkey.setTranslationY(200f);
            monkey.setScale(1.1f);
        }
    }

    public void Only() {



        SharedPreferences dataSave = getSharedPreferences("firstLog", 0);

        if (dataSave.getString("firstTime", "").equals("no")) { // first run is happened
            CountDownTimer downTimer = new CountDownTimer(1000, 1000) {

                @Override
                public void onTick(long l) {

                }

                @Override
                public void onFinish() {
                    Intent inte = new Intent(MainActivity.this, SecondActivity.class);
                    MainActivity.this.startActivity(inte);
                    overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
                    finish();

                }
            }.start();


        } else { //  this is the first run of application
            SharedPreferences.Editor editor = dataSave.edit();
            editor.putString("firstTime", "no");
            editor.apply();

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StatusBarUtil.setTransparent(this);
        setContentView(R.layout.activity_main);
        String channeN = "quizo";
        view= findViewById(R.id.rl);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(channeN, channeN, importance);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
            isNetworkConnectionAvailable();
        }

    }
}


