package com.quizo

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.LocationManager
import android.os.AsyncTask
import android.os.Bundle
import android.os.Looper
import android.provider.Settings
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.view.animation.LinearInterpolator
import android.view.animation.RotateAnimation
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.location.*
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.bottomnavigation.LabelVisibilityMode
import com.google.android.material.card.MaterialCardView
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.jaeger.library.StatusBarUtil
import com.kwabenaberko.openweathermaplib.constants.Units
import com.kwabenaberko.openweathermaplib.implementation.OpenWeatherMapHelper
import com.kwabenaberko.openweathermaplib.implementation.callbacks.CurrentWeatherCallback
import com.kwabenaberko.openweathermaplib.models.currentweather.CurrentWeather
import com.quizo.NewsActivity
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.util.*

class LoggedIn : AppCompatActivity() {
    var LAT = 0.0
    var LON = 0.0
    var JDATA: String? = null
    var weather: LottieAnimationView? = null
    var PERMISSION_ID = 44
    var mFusedLocationClient: FusedLocationProviderClient? = null
    var firebaseAuth = FirebaseAuth.getInstance()
    val currentUser = firebaseAuth.currentUser
    val ID = Objects.requireNonNull(currentUser)!!.displayName
    var googleSignInClient: GoogleSignInClient? = null
    private val mLocationCallback: LocationCallback = object : LocationCallback() {
        override fun onLocationResult(locationResult: LocationResult) {
            val mLastLocation = locationResult.lastLocation
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        lastLocation()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.logged)
        val ref = findViewById<LottieAnimationView>(R.id.refresh)
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.btmnav)
        bottomNavigationView.labelVisibilityMode = LabelVisibilityMode.LABEL_VISIBILITY_UNLABELED
        bottomNavigationView.setOnNavigationItemSelectedListener(BottomNavigationView.OnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.page_2 -> {
                    startActivity(Intent(applicationContext, NewsActivity::class.java))
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    return@OnNavigationItemSelectedListener true
                }
                R.id.page_1 -> return@OnNavigationItemSelectedListener true
                R.id.page_3 -> {
                    startActivity(Intent(applicationContext, OffActivity::class.java))
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                }
            }
            false
        })
        ref.setOnClickListener {
            ref.playAnimation()
            lastLocation()
        }
        val CD = findViewById<MaterialCardView>(R.id.wtcd)
        val mfab = findViewById<ExtendedFloatingActionButton>(R.id.botfab)
        mfab.setOnClickListener {
            val v = findViewById<View>(R.id.botfab)
            startRevealActivity(v)
        }
        saved()
        StatusBarUtil.setTransparent(this)
        val main = findViewById<TextView>(R.id.main)
        main.text = "Hello $ID!"
        main.setOnClickListener { chat() }
        val animation = AnimationUtils.loadAnimation(applicationContext, R.anim.fadein)
        main.startAnimation(animation)
        //findViewById(R.id.buttonDisconnect).setOnClickListener(this);
        googleSignInClient = GoogleSignIn.getClient(this, GoogleSignInOptions.DEFAULT_SIGN_IN)
        firebaseAuth = FirebaseAuth.getInstance()
        expand()
    }

    private fun expand() {
        val CoronaCard = findViewById<MaterialCardView>(R.id.coroCD)
        val expL = findViewById<LinearLayout>(R.id.expandL)
        val image = findViewById<ImageView>(R.id.img)
        CoronaCard.setOnClickListener {
            if (expL.visibility == View.GONE) {
                TransitionManager.beginDelayedTransition(CoronaCard, AutoTransition())
                expL.visibility = View.VISIBLE
                val rotate = RotateAnimation(0F, 180F, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f)
                rotate.duration = 500
                rotate.interpolator = LinearInterpolator()
                rotate.fillAfter = true
                image.startAnimation(rotate)
            } else {
                TransitionManager.beginDelayedTransition(CoronaCard, AutoTransition())
                expL.visibility = View.GONE
                val rotate = RotateAnimation(180F, 0F, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f)
                rotate.duration = 500
                rotate.interpolator = LinearInterpolator()
                rotate.fillAfter = true
                image.startAnimation(rotate)
            }
        }
    }

    @Throws(JSONException::class)
    private fun extrD(JSD: String) {
        val STATES = arrayOf("Maharashtra", "Tamil Nadu", "Delhi", "Kerala", "Telangana", "Uttar Pradesh", "Andhra Pradesh", "Rajasthan", "Madhya Pradesh", "Karnataka", "Gujarat", "Jammu and Kashmir", "Haryana", "Punjab"
                , "West Bengal"
                , "Bihar"
                , "Assam"
                , "Uttarakhand"
                , "Odisha"
                , "Chandigarh"
                , "Ladakh"
                , "Andaman and Nicobar Islands"
                , "Chhattisgarh"
                , "Goa"
                , "Himachal Pradesh"
                , "Puducherry"
                , "Jharkhand"
                , "Manipur")
        runOnUiThread {
            val recyclerView = findViewById<RecyclerView>(R.id.recycler_view)
            val datalist: MutableList<CoData> = ArrayList()
            val mAdapter = DataAdapter(datalist)
            val layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(applicationContext, RecyclerView.HORIZONTAL, false)
            recyclerView.layoutManager = layoutManager
            recyclerView.adapter = mAdapter
            var data: CoData
            try {
                val jobj = JSONObject(JSD)
                val states = jobj.getJSONObject("state_wise")
                for (i in 0..27) {
                    val getS = states.getJSONObject(STATES[i])
                    val Active = getS.getInt("active")
                    val Recovered = getS.getInt("recovered")
                    val Deaths = getS.getInt("deaths")
                    val Confirmed = getS.getInt("confirmed")
                    data = CoData(STATES[i], "ACTIVE \n$Active", "DEATHS \n$Deaths", "RECOVERED \n$Recovered", "CONFIRMED \n$Confirmed")
                    datalist.add(data)
                }
            } catch (e: JSONException) {
                e.printStackTrace()
            }
        }
    }

    private fun weather(Lat: Double, Lon: Double) {
        val helper = OpenWeatherMapHelper("236011d2dcb15854914e1db09e019d42")
        helper.setUnits(Units.METRIC)
        helper.getCurrentWeatherByGeoCoordinates(Lat, Lon, object : CurrentWeatherCallback {
            override fun onSuccess(currentWeather: CurrentWeather) {
                val deg = findViewById<TextView>(R.id.deg)
                val city = findViewById<TextView>(R.id.city)
                val desc = findViewById<TextView>(R.id.desc)
                val wind = findViewById<TextView>(R.id.wind)
                val d = currentWeather.weather[0].description
                val icon = currentWeather.weather[0].icon
                val de = currentWeather.main.tempMax
                val degr = de.toInt()
                val builder = StringBuilder();
                builder.append(degr).append("\u2103")
                deg.setText(builder.toString())
                city.text = currentWeather.name + "," + currentWeather.sys.country
                desc.text = currentWeather.weather[0].description
                wind.text = "Wind Speed: " + currentWeather.wind.speed
                Log.v(TAG, """
     Coordinates: ${currentWeather.coord.lat}, ${currentWeather.coord.lon}
     Weather Description: ${currentWeather.weather[0].description}
     Temperature: ${currentWeather.main.tempMax}
     Wind Speed: ${currentWeather.wind.speed}
     City, Country: ${currentWeather.name}, ${currentWeather.sys.country}
     """.trimIndent()
                )
                wicon(icon)
                geo(Lat, Lon)
            }

            override fun onFailure(throwable: Throwable) {
                Log.v(TAG, throwable.message)
            }
        })
    }

    private fun geo(lat: Double, lon: Double) {
        val geocoder: Geocoder
        val addresses: List<Address>
        geocoder = Geocoder(applicationContext, Locale.getDefault())
        try {
            addresses = geocoder.getFromLocation(lat, lon, 1) // Here 1 represent max location result to returned, by documents it recommended 1 to 5
            val state = addresses[0].adminArea
            Log.d(TAG, "geo: STATE =$state")
            rip().execute(state)
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finishAffinity()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    private fun wicon(d: String) {
        weather = findViewById(R.id.anim)
        when (d) {
            "01d" -> {
                weather?.setAnimation(R.raw.weather_sunny)
                weather?.playAnimation()
            }
            "01n" -> {
                weather?.setAnimation(R.raw.weather_night)
                weather?.playAnimation()
            }
            "02d", "03d" -> {
                weather?.setAnimation(R.raw.weather_partly_cloudy)
                weather?.playAnimation()
            }
            "02n", "03n" -> {
                weather?.setAnimation(R.raw.weather_cloudynight)
                weather?.playAnimation()
            }
            "04d", "04n" -> {
                weather?.setAnimation(R.raw.weather_windy)
                weather?.playAnimation()
            }
            "09d", "10d" -> {
                weather?.setAnimation(R.raw.weather_partly_shower)
                weather?.playAnimation()
            }
            "09n", "10n" -> {
                weather?.setAnimation(R.raw.weather_rainynight)
                weather?.playAnimation()
            }
            "11d", "11n" -> {
                weather?.setAnimation(R.raw.weather_storm)
                weather?.playAnimation()
            }
            "13d" -> {
                weather?.setAnimation(R.raw.weather_snow_sunny)
                weather?.playAnimation()
            }
            "13n" -> {
                weather?.setAnimation(R.raw.weather_snownight)
                weather?.playAnimation()
            }
            "50d", "50n" -> {
                weather?.setAnimation(R.raw.weather_mist)
                weather?.playAnimation()
            }
        }
    }

    private fun signOut() {
        // Firebase sign out
        firebaseAuth.signOut()
        // Google sign out
        googleSignInClient!!.signOut().addOnCompleteListener(this
        ) { // Google Sign In failed, update UI appropriately
            loggedout()
            Log.w(TAG, "Signed out of google")
        }
    }

    private fun loggedout() {
        val inte = Intent(this, SecondActivity::class.java)
        this.startActivity(inte)
        finish()
    }

    fun chat() {
        val intex = Intent(this, NewsActivity::class.java)
        this.startActivity(intex)
    }

    fun saved() {
        val dataS = getSharedPreferences("first", 0)
        if (dataS.getString("firstime", "") == "no") { // first run is happened
        } else { //  this is the first run of application
            val intent = Intent(this, ChatActivity::class.java)
            this.startActivity(intent)
            finish()
            val editor = dataS.edit()
            editor.putString("firstime", "no")
            editor.apply()
        }
    }

    @SuppressLint("MissingPermission")
    private fun lastLocation() {
            if (checkPermissions()) {
                if (isLocationEnabled) {
                    mFusedLocationClient!!.lastLocation.addOnCompleteListener { task ->
                        val location = task.result
                        if (location == null) {
                            requestNewLocationData()
                        } else {
                            LAT = location.latitude
                            LON = location.longitude
                            Log.d(TAG, "onComplete: $LAT$LON")
                            weather(LAT, LON)
                        }
                    }
                } else {
                    val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                    startActivity(intent)
                }
            } else {
                requestPermissions()
            }
        }

    @SuppressLint("MissingPermission")
    private fun requestNewLocationData() {
        val mLocationRequest = LocationRequest()
        mLocationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        mLocationRequest.interval = 0
        mLocationRequest.fastestInterval = 0
        mLocationRequest.numUpdates = 1
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        mFusedLocationClient?.requestLocationUpdates(
                mLocationRequest, mLocationCallback,
                Looper.myLooper()
        )
    }

    private fun checkPermissions(): Boolean {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermissions() {
        ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION),
                PERMISSION_ID
        )
    }

    private val isLocationEnabled: Boolean
        private get() {
            val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(
                    LocationManager.NETWORK_PROVIDER
            )
        }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_ID) {
            if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                lastLocation()
            }
        }
    }

    public override fun onResume() {
        super.onResume()
        if (checkPermissions()) {
            lastLocation()
        }
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.btmnav)
        bottomNavigationView.selectedItemId = R.id.page_1
    }

    private fun startRevealActivity(v: View) {
        //calculates the center of the View v you are passing
        val revealX = v.x.toInt() + v.width / 2
        val revealY = v.y.toInt() + v.height / 2
        Log.d(TAG, "startRevealActivity:$revealX,$revealY")
        //create an intent, that launches the second activity and pass the x and y coordinates
        val intent = Intent(this, bot::class.java)
        intent.putExtra(RevealAnimation.EXTRA_CIRCULAR_REVEAL_X, revealX)
        intent.putExtra(RevealAnimation.EXTRA_CIRCULAR_REVEAL_Y, revealY)

        //just start the activity as an shared transition, but set the options bundle to null
        ActivityCompat.startActivity(this, intent, null)

        //to prevent strange behaviours override the pending transitions
        overridePendingTransition(0, 0)
    }

    override fun onPostResume() {
        super.onPostResume()
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.btmnav)
        bottomNavigationView.selectedItemId = R.id.page_1
    }

    private inner class rip : AsyncTask<String?, Void?, Void?>() {
        protected override fun doInBackground(vararg strings: String?): Void? {
            val state = strings[0]
            val client = OkHttpClient()
            val request = Request.Builder()
                    .url("https://corona-virus-world-and-india-data.p.rapidapi.com/api_india")
                    .method("GET", null)
                    .addHeader("x-rapidapi-host", "corona-virus-world-and-india-data.p.rapidapi.com")
                    .addHeader("x-rapidapi-key", "HaCkNboy9LmshPV8bJ33e3h7iLimp1uHuayjsnJId6hYtSZbCz")
                    .build()
            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    runOnUiThread { }
                }

                @Throws(IOException::class)
                override fun onResponse(call: Call, response: Response) {
                    val Jdata = response.body()!!.string()
                    Log.d("RESULTTTT", "onResponse: $Jdata")
                    runOnUiThread {
                        try {
                            extrD(Jdata)
                            val jobj = JSONObject(Jdata)
                            val states = jobj.getJSONObject("state_wise")
                            val total = jobj.getJSONObject("total_values")
                            val CONI = total.getInt("confirmed")
                            val ActiveI = total.getInt("active")
                            val DeathsI = total.getInt("deaths")
                            val RecoveredI = total.getInt("recovered")
                            val getS = states.getJSONObject(state)
                            val Active = getS.getInt("active")
                            val Recovered = getS.getInt("recovered")
                            val Deaths = getS.getInt("deaths")
                            val Confirmed = getS.getInt("confirmed")
                            val a = findViewById<TextView>(R.id.act)
                            val c = findViewById<TextView>(R.id.conf)
                            val iny = findViewById<TextView>(R.id.inyour)
                            val r = findViewById<TextView>(R.id.rec)
                            val d = findViewById<TextView>(R.id.dea)
                            val a1 = findViewById<TextView>(R.id.act1)
                            val c1 = findViewById<TextView>(R.id.conf1)
                            val iny1 = findViewById<TextView>(R.id.inyour1)
                            val r1 = findViewById<TextView>(R.id.rec1)
                            val d1 = findViewById<TextView>(R.id.dea1)
                            iny.text = "Currently in $state"
                            a.text = "ACTIVE \n$Active"
                            c.text = "CONFIRMED \n$Confirmed"
                            r.text = "RECOVERED \n$Recovered"
                            d.text = "DEATHS \n$Deaths"
                            iny1.text = "Currently in India"
                            a1.text = "ACTIVE \n$ActiveI"
                            c1.text = "CONFIRMED \n$CONI"
                            r1.text = "RECOVERED \n$RecoveredI"
                            d1.text = "DEATHS \n$DeathsI"
                            Log.d(TAG, "run: ACTIVE $Active")
                        } catch (e: JSONException) {
                            e.printStackTrace()
                        }
                    }
                }
            })
            return null
        }
    }

    companion object {
        private const val TAG = "MainActivity"
        private const val ARG_NAME = "username"
        @JvmStatic
        fun startActivity(context: Context, username: String?) {
            val intent = Intent(context, LoggedIn::class.java)
            intent.putExtra(ARG_NAME, username)
            context.startActivity(intent)
        }
    }
}