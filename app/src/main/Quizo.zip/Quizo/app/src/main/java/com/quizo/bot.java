package com.quizo;

import android.app.ActionBar;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.ibm.watson.developer_cloud.assistant.v1.Assistant;
import com.ibm.watson.developer_cloud.assistant.v1.model.InputData;
import com.ibm.watson.developer_cloud.assistant.v1.model.MessageOptions;
import com.ibm.watson.developer_cloud.assistant.v1.model.MessageResponse;
import com.jaeger.library.StatusBarUtil;

import java.util.ArrayList;
import java.util.Objects;

import static com.quizo.R.*;

public class bot extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ChatAdapter mAdapter;
    private ArrayList messageArrayList;
    private EditText inputMessage;
    private boolean initialRequest = false;
    ProgressDialog dialog;
    //private Map<String,Object> context = new HashMap<>();
    com.ibm.watson.developer_cloud.assistant.v1.model.Context context = null;
    private static String TAG = "BotActivity";
    RevealAnimation mRevealAnimation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.bot);
        StatusBarUtil.setTransparent(this);
        RelativeLayout le=findViewById(R.id.lr);
        Intent intent = this.getIntent();   //get the intent to recieve the x and y coords, that you passed before

        FrameLayout rootLayout = findViewById(id.bot); //there you have to get the root layout of your second activity
        mRevealAnimation = new RevealAnimation(rootLayout, intent, this);
        inputMessage = findViewById(id.message);
        final ExtendedFloatingActionButton btnSend = findViewById(id.btn_send);
        recyclerView = findViewById(id.recycler_view);
        recyclerView = findViewById(id.recycler_view);
        dialog = new ProgressDialog(this);
        messageArrayList = new ArrayList<>();
        mAdapter = new ChatAdapter(messageArrayList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);
        this.initialRequest = true;
        sendMessage();
          Vib();
inputMessage.addTextChangedListener(new TextWatcher() {
    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        btnSend.setEnabled(false);
        btnSend.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(color.light_grey)));
    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        if(charSequence.toString().trim().length()==0){
            btnSend.setEnabled(false);
            btnSend.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(color.light_grey)));
        } else {
            btnSend.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(color.colorPrimary)));
            btnSend.setEnabled(true);
        }
    }

    @Override
    public void afterTextChanged(Editable editable) {

    }
});


    btnSend.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View v) {

            sendMessage();
        }
    });



    }

    private void sendMessage() {

        final String inputmessage = this.inputMessage.getText().toString().trim();
        if(!this.initialRequest) {
            Message inputMessage = new Message();
            inputMessage.setMessage(inputmessage);
            inputMessage.setId("1");
            messageArrayList.add(inputMessage);

        }
        else
        {
            Message inputMessage = new Message();
            inputMessage.setMessage(inputmessage);
            inputMessage.setId("100");
            this.initialRequest = false;

        }

        this.inputMessage.setText("");
        mAdapter.notifyDataSetChanged();

        Thread thread = new Thread(new Runnable(){
            public void run() {
                try {

                    Assistant assistantservice = new Assistant("2018-02-16");
                    //If you like to use USERNAME AND PASSWORD
                    //Your Username: "apikey", password: "<APIKEY_VALUE>"
                    assistantservice.setUsernameAndPassword("apikey", "l78660vsmrfVIWTOp716dXCHRxCnTDOmWxedbLItuqlY");

                    //TODO: Uncomment this line if you want to use API KEY
                    //assistantservice.setApiKey("l78660vsmrfVIWTOp716dXCHRxCnTDOmWxedbLItuqlY");

                    //Set endpoint which is the URL. Default value: https://gateway.watsonplatform.net/assistant/api
                    assistantservice.setEndPoint("https://api.eu-gb.assistant.watson.cloud.ibm.com/instances/3a544229-13a5-41bb-a860-9b8f90edb923");
                    InputData input = new InputData.Builder(inputmessage).build();
                    //WORKSPACES are now SKILLS
                    MessageOptions options = new MessageOptions.Builder().workspaceId("e7d655d8-b810-4fc6-9646-31cd5700e57f").input(input).context(context).build();
                    MessageResponse response = assistantservice.message(options).execute();
                    String uu = "";

                    Log.i(TAG, "run nonloop: "+response);

                    int length=response.getOutput().getText().size();
                    Log.i(TAG, "run length : "+length);
                    String outputText;
                    outputText = "";
                    if(length>1) {
                        for (int i = 0; i < length; i++) {
                            outputText += '\n' + response.getOutput().getText().get(i).trim();
                        }
                    }
                    else
                        outputText = response.getOutput().getText().get(0);

                    Log.i(TAG, "run loop: "+outputText);
                    //Passing Context of last conversation
                    if(response.getContext() !=null)
                    {
                        //context.clear();
                        context = response.getContext();

                    }
                    Message outMessage=new Message();
                    if(response!=null)
                    {
                        if(response.getOutput()!=null && response.getOutput().containsKey("text"))
                        {
                            ArrayList responseList = (ArrayList) response.getOutput().get("text");
                            if(null !=responseList && responseList.size()>0){
                                outMessage.setMessage(outputText);
                                outMessage.setId("2");
                            }
                            messageArrayList.add(outMessage);
                        }

                        runOnUiThread(new Runnable() {
                            public void run() {
                                anima();
                                mAdapter.notifyDataSetChanged();
                                if (mAdapter.getItemCount() > 1) {
                                    Objects.requireNonNull(recyclerView.getLayoutManager()).smoothScrollToPosition(recyclerView, null, mAdapter.getItemCount()-1);

                                }

                            }
                        });


                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        thread.start();

    }

    private void anima() {
        RelativeLayout le = findViewById(R.id.lr);
        le.setVisibility(View.GONE);

    }

    @Override
    public void onBackPressed() {
        mRevealAnimation.unRevealActivity();
    }

    public void Vib() {
        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
// Vibrate for 500 milliseconds
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(20, 50));
        } else {
            //deprecated in API 26
            v.vibrate(500);
        }
    }
}
