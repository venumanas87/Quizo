package com.quizo

import android.app.ActivityOptions
import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.transition.AutoTransition
import android.transition.ChangeBounds
import android.transition.TransitionManager
import android.util.Log
import android.view.View
import android.view.Window
import android.view.animation.Animation
import android.view.animation.LinearInterpolator
import android.view.animation.RotateAnimation
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
import com.adcolony.sdk.AdColony
import com.adcolony.sdk.AdColonyAppOptions
import com.adcolony.sdk.AdColonyInterstitial
import com.adcolony.sdk.AdColonyInterstitialListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.InterstitialAd
import com.google.android.gms.ads.MobileAds
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.bottomnavigation.LabelVisibilityMode
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.google.android.material.transition.MaterialContainerTransformSharedElementCallback
import com.jaeger.library.StatusBarUtil
import com.quizo.R.layout
import com.skydoves.transformationlayout.TransformationCompat.startActivity
import com.skydoves.transformationlayout.TransformationLayout
import com.skydoves.transformationlayout.onTransformationStartContainer
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.io.IOException
import java.util.*

class NewsActivity : AppCompatActivity() {
    var newsAdapter: NewsAdapter? = null
    var data: NewsData? = null
    var newsDataList: MutableList<NewsData>? = null
    var newsAdapter1: NewsAdapter? = null
    var data1: NewsData? = null
    var newsDataList1: MutableList<NewsData>? = null
    var progressBar1: ProgressBar? = null
    var nat: TextView? = null
    var tv1: TextView? = null
    var re: TextView? = null
    var swipeRefreshLayout: SwipeRefreshLayout? = null
    var bottomNavigationView: CustomBottomNavigationView? = null
    var chipGroup: ChipGroup? = null
    var lang = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        window.requestFeature(Window.FEATURE_ACTIVITY_TRANSITIONS)

        setExitSharedElementCallback(MaterialContainerTransformSharedElementCallback())
        super.onCreate(savedInstanceState)
        AdColony.configure(this, APP_ID, ZONE_IDS)
        setContentView(layout.news_layout)
        StatusBarUtil.setTransparent(this)
        bottomNavigationView = findViewById(R.id.btmnav)
        bottomNavigationView?.setSelectedItemId(R.id.page_2)
        val mfab = findViewById<ExtendedFloatingActionButton>(R.id.botfab)
        val mInterstitialAd: InterstitialAd
        MobileAds.initialize(this) { }
        mInterstitialAd = InterstitialAd(this)
        mInterstitialAd.adUnitId = "ca-app-pub-2569821792203202/4563281256"
        //ca-app-pub-2569821792203202/4563281256 orig
        //ca-app-pub-3940256099942544/1033173712 test
        mInterstitialAd.loadAd(AdRequest.Builder().build())
        val listener: AdColonyInterstitialListener = object : AdColonyInterstitialListener() {
            override fun onRequestFilled(ad: AdColonyInterstitial) {
                /** Store and use this ad object to show your ad when appropriate  */
                ad.show()
            }
        }
        val consent = "1"
        val options = AdColonyAppOptions()
                .setGDPRConsentString(consent)
                .setGDPRRequired(true)

// Pass options object to AdColony in configure call, or later in the session via
// AdColony.setAppOptions().
        AdColony.configure(this, options, APP_ID, ZONE_IDS)
        AdColony.requestInterstitial(ZONE_IDS, listener)
        re = findViewById(R.id.re)
        progressBar1 = findViewById(R.id.progress_circular)
        swipeRefreshLayout = findViewById(R.id.swipe)
        swipeRefreshLayout?.setEnabled(false)
        swipeRefreshLayout?.setOnRefreshListener(OnRefreshListener {
            Extract().execute()
            swipeRefreshLayout?.setRefreshing(true)
        })
        val national: Chip
        val world: Chip
        val sci: Chip
        val tech: Chip
        val startp: Chip
        val busi: Chip
        val sports: Chip
        val poli: Chip
        val auto: Chip
        val miscl: Chip
        val eng: Chip
        val hin: Chip
        chipGroup = findViewById(R.id.chpgrp)
        tv1 = findViewById(R.id.tv1)
        eng = findViewById(R.id.english)
        eng.isChecked = true
        hin = findViewById(R.id.hindi)
        national = findViewById(R.id.national)
        national.isChecked = true
        sci = findViewById(R.id.science)
        tech = findViewById(R.id.tech)
        startp = findViewById(R.id.startup)
        busi = findViewById(R.id.busi)
        sports = findViewById(R.id.sports)
        poli = findViewById(R.id.politics)
        auto = findViewById(R.id.automob)
        miscl = findViewById(R.id.miscl)
        world = findViewById(R.id.world)
        eng.setOnClickListener {
            eng.isChecked = true
            lang = 0
            Extract().execute()
            national.isChecked = true
        }
        hin.setOnClickListener {
            hin.isChecked = true
            lang = 1
            Extract().execute()
            national.isChecked = true
        }
        national.setOnClickListener {
            Extract().execute()
            national.isChecked = true
            if (mInterstitialAd.isLoaded) {
                mInterstitialAd.show()
            } else {
                Log.d("TAG", "The interstitial wasn't loaded yet.")
            }
        }
        world.setOnClickListener {
            ExtractC().execute("world")
            world.isChecked = true
            if (mInterstitialAd.isLoaded) {
                mInterstitialAd.show()
            } else {
                Log.d("TAG", "The interstitial wasn't loaded yet.")
            }
        }
        sci.setOnClickListener {
            ExtractC().execute("science")
            sci.isChecked = true
        }
        tech.setOnClickListener {
            ExtractC().execute("technology")
            tech.isChecked = true
        }
        startp.setOnClickListener {
            ExtractC().execute("startup")
            startp.isChecked = true
        }
        busi.setOnClickListener {
            ExtractC().execute("business")
            busi.isChecked = true
        }
        sports.setOnClickListener {
            ExtractC().execute("sports")
            sports.isChecked = true
        }
        poli.setOnClickListener {
            ExtractC().execute("politics")
            poli.isChecked = true
        }
        auto.setOnClickListener {
            ExtractC().execute("automobile")
            auto.isChecked = true
        }
        miscl.setOnClickListener {
            ExtractC().execute("miscellaneous")
            miscl.isChecked = true
        }
        nat = findViewById(R.id.nat)
        val transformationLayout = findViewById<TransformationLayout>(R.id.transL)
        val recyclerView = findViewById<RecyclerView>(R.id.recycler_view1)
        newsDataList = ArrayList()
        newsAdapter = NewsAdapter(newsDataList as ArrayList<NewsData>, CustomStoryClick { v, position ->
            val newsData = (newsDataList as ArrayList<NewsData>).get(position)
            val i = Intent(v.context, SharedeleClass::class.java)
            i.putExtra("activity", newsData.activi)
            i.putExtra("title", newsData.head)
            i.putExtra("desc", newsData.cont)
            i.putExtra("auth", newsData.auth)
            i.putExtra("date", newsData.date)
            i.putExtra("url", newsData.url)
            val options = ActivityOptions.makeSceneTransitionAnimation(
                    this,
                    v,
                    "shared" // The transition name to be matched in Activity B.
            )
            startActivity(i, options.toBundle())

            /* ActivityOptionsCompat options = ActivityOptionsCompat.
                        makeSceneTransitionAnimation((Activity) v.getContext(),v, "shared");
                v.getContext().startActivity(i, options.toBundle());*/
        })
        val layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(applicationContext, RecyclerView.HORIZONTAL, false)
        recyclerView.layoutManager = layoutManager
        recyclerView.adapter = newsAdapter

        //EDITOR RECYCLER VIEW
        val recyclerView1 = findViewById<RecyclerView>(R.id.recycler_view)
        newsDataList1 = ArrayList()
        newsAdapter1 = NewsAdapter(newsDataList1 as ArrayList<NewsData>, CustomStoryClick { v, position -> })
        val layoutManager1: RecyclerView.LayoutManager = LinearLayoutManager(applicationContext, RecyclerView.HORIZONTAL, false)
        recyclerView1.layoutManager = layoutManager1
        recyclerView1.adapter = newsAdapter1
        Extract().execute()
        mfab.setOnClickListener {
            val v = findViewById<View>(R.id.botfab)
            startRevealActivity(v)
        }
        bottomNavigationView?.setItemHorizontalTranslationEnabled(false)
        bottomNavigationView?.setLabelVisibilityMode(LabelVisibilityMode.LABEL_VISIBILITY_UNLABELED)
        bottomNavigationView?.setOnNavigationItemSelectedListener(BottomNavigationView.OnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.page_1 -> {
                    startActivity(Intent(applicationContext, LoggedIn::class.java))
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    finish()
                    return@OnNavigationItemSelectedListener true
                }
                R.id.page_2 -> return@OnNavigationItemSelectedListener true
                R.id.page_3 -> {
                    startActivity(Intent(applicationContext, OffActivity::class.java))
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    finish()
                }
            }
            false
        })
        Editorials().execute()
        EditTele().execute()
        expands()
    }

    private fun expands() {
        val CoronaCard = findViewById<CardView>(R.id.rl2)
        val expL = findViewById<RelativeLayout>(R.id.hidl)
        val image = findViewById<ImageView>(R.id.more)
        expL.visibility = View.GONE
        CoronaCard.setOnClickListener {
            if (expL.visibility == View.GONE) {
                TransitionManager.beginDelayedTransition(CoronaCard, AutoTransition())
                expL.visibility = View.VISIBLE
                val rotate = RotateAnimation(0F, 180F, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f)
                rotate.duration = 50
                rotate.interpolator = LinearInterpolator()
                rotate.fillAfter = true
                image.startAnimation(rotate)
            } else {
                TransitionManager.beginDelayedTransition(CoronaCard, ChangeBounds())
                expL.visibility = View.GONE
                val rotate = RotateAnimation(180F, 0F, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f)
                rotate.duration = 50
                rotate.interpolator = LinearInterpolator()
                rotate.fillAfter = true
                image.startAnimation(rotate)
            }
        }
    }

    private fun startRevealActivity(v: View) {
        //calculates the center of the View v you are passing
        val revealX = v.x.toInt() + v.width / 2
        val revealY = v.y.toInt() + v.height / 2
        Log.d("NewsActivity", "startRevealActivity:$revealX,$revealY")
        //create an intent, that launches the second activity and pass the x and y coordinates
        val intent = Intent(this, bot::class.java)
        intent.putExtra(RevealAnimation.EXTRA_CIRCULAR_REVEAL_X, revealX)
        intent.putExtra(RevealAnimation.EXTRA_CIRCULAR_REVEAL_Y, revealY)

        //just start the activity as an shared transition, but set the options bundle to null
        ActivityCompat.startActivity(this, intent, null)

        //to prevent strange behaviours override the pending transitions
        overridePendingTransition(0, 0)
    }

    private inner class Extract : AsyncTask<Void?, Void?, Void?>() {



        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            swipeRefreshLayout!!.isRefreshing = false
            newsAdapter!!.notifyDataSetChanged()
            progressBar1!!.visibility = View.GONE
            nat!!.visibility = View.VISIBLE
            tv1!!.visibility = View.VISIBLE
            chipGroup!!.visibility = View.VISIBLE
        }

        override fun onPreExecute() {
            super.onPreExecute()
            re!!.visibility = View.GONE
            newsDataList!!.clear()
            nat!!.visibility = View.INVISIBLE
            progressBar1!!.visibility = View.VISIBLE
            tv1!!.visibility = View.GONE
            chipGroup!!.visibility = View.GONE
        }

        override fun doInBackground(vararg p0: Void?): Void? {
            var url = ""
            url = if (lang == 0) {
                "https://inshorts.com/en/read"
            } else {
                "https://inshorts.com/hi/read"
            }
            var doc: Document? = null
            try {
                doc = Jsoup.connect(url).get()
                val title = doc.select("div.news-card-title")
                val author = doc.select("div.news-card-author-time")
                val autho = author.select("span[class='author']")
                val time = author.select("span[class='time']")
                val date = author.select("span[class='date']")
                val style = title.select("a")
                val span = style.select("span[itemprop]")
                val image = doc.select("div.news-card-image")
                val cont = doc.select("div.news-card-content")
                val contt = cont.select("div[itemprop]")
                val size = span.size
                Log.d("LINKS", "onCreate: " + title.size)
                for (i in 0 until size) {
                    val CONT = contt.eq(i).text()
                    val tit = span.eq(i).text()
                    val ftime = time.eq(i).text()
                    val fdate = date.eq(i).text()
                    val tida = "$fdate on $ftime"
                    val auth = autho.eq(i).text()
                    val imgurl = image.eq(i).attr("style").split("'").toTypedArray()[1]
                    Log.d("NEXTDATA", "doInBackground: EXTRACT THE FINAL SOURCES$tit   $imgurl $tida")
                    ad(tit, imgurl, CONT, auth, tida)
                }
            } catch (e: IOException) {
                re!!.visibility = View.VISIBLE
                swipeRefreshLayout!!.isEnabled = true
                e.printStackTrace()
            }
            return null
        }


    }

    private inner class ExtractC : AsyncTask<String?, Void?, Void?>() {

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            newsAdapter!!.notifyDataSetChanged()
            progressBar1!!.visibility = View.GONE
            nat!!.visibility = View.VISIBLE
        }

        override fun onPreExecute() {
            newsDataList!!.clear()
            super.onPreExecute()
            nat!!.visibility = View.INVISIBLE
            progressBar1!!.visibility = View.VISIBLE
        }

        override fun doInBackground(vararg p0: String?): Void? {
            var doc: Document? = null
            val cat = p0[0]
            var url = "https://inshorts.com/en/read/"
            url = if (lang == 0) {
                "https://inshorts.com/en/read/"
            } else {
                "https://inshorts.com/hi/read/"
            }
            Log.d("News", "Acessing the link through asunkTaask  $url$cat")
            try {
                doc = Jsoup.connect(url + cat).get()
                val title = doc.select("div.news-card-title")
                val author = doc.select("div.news-card-author-time")
                val autho = author.select("span[class='author']")
                val time = author.select("span[class='time']")
                val date = author.select("span[class='date']")
                val style = title.select("a")
                val span = style.select("span[itemprop]")
                val image = doc.select("div.news-card-image")
                val cont = doc.select("div.news-card-content")
                val contt = cont.select("div[itemprop]")
                val size = span.size
                Log.d("LINKS", "onCreate: " + title.size)
                for (i in 0 until size) {
                    val CONT = contt.eq(i).text()
                    val tit = span.eq(i).text()
                    val ftime = time.eq(i).text()
                    val fdate = date.eq(i).text()
                    val tida = "$fdate on $ftime"
                    val auth = autho.eq(i).text()
                    val imgurl = image.eq(i).attr("style").split("'").toTypedArray()[1]
                    Log.d("NEXTDATA", "doInBackground: EXTRACT THE FINAL SOURCES$tit   $imgurl $tida")
                    ad(tit, imgurl, CONT, auth, tida)
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            return null
        }
    }

    //                      THE HINDUU /////////////////////////////////////////////
    private inner class Editorials : AsyncTask<Void?, Void?, Void?>() {

        override fun doInBackground(vararg p0: Void?): Void? {
            var doc: Document? = null
            try {
                doc = Jsoup.connect("https://www.thehindu.com/opinion/editorial/").get()
                val edcard = doc.select("div.ES2-100x4-text1")
                val h2 = edcard.select("h2")
                val links = h2.select("a")
                for (i in 0..1) {
                    val link = links.eq(i).attr("href")
                    Log.d("EDITORIAL", "doInBackground: $link")
                    ExEdit().execute(link)
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
        return null
        }
    }

    private inner class ExEdit : AsyncTask<String?, Void?, Void?>() {
         override fun doInBackground(vararg strings: String?): Void? {
            var doc: Document?
            val url = strings[0]
            try {
                doc = Jsoup.connect(url).get()
                val div = doc.select("div")
                val p = div.select("p.drop-caps")
                val h2 = doc.select("h2")
                val timestamp = doc.select("span[class='blue-color ksl-time-stamp']")
                val td = timestamp.first().text()
                val desc = p.first().text()
                val Btitle = h2.first().text()
                val urli = "https://exchange4media.gumlet.com/news-photo/93208-hindunew.jpg"
                ad1(Btitle, urli, desc, "Editor,The Hindu", td)
                // Log.d("EXEDIT", "doInBackground: "+ desc+ " : " + td+ Btitle);
            } catch (e: IOException) {
                e.printStackTrace()
            }
            return null
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            newsAdapter1!!.notifyDataSetChanged()
        }
    }

    /////////////////////////////          TELEGRAPH //////////////////////////////////////////////////
    private inner class EditTele : AsyncTask<Void?, Void?, Void?>() {
         override fun doInBackground(vararg voids: Void?): Void? {
            var doc: Document? = null
            try {
                doc = Jsoup.connect("https://www.telegraphindia.com/topic/editorial").get()
                val maindiv = doc.select("div.storyBox")
                val p = maindiv.select("p")
                val links = p.select("a")
                val curd = maindiv.select("h4").first().text()
                var size = 0
                for (d in maindiv.select("h4")) {
                    if (d.text() == curd) size++
                }
                Log.d("TESTING", "doInBackground: $size")
                for (i in 0 until size) {
                    val bas = "https://www.telegraphindia.com"
                    val link = links.eq(i).attr("abs:href")
                    Log.d("TEle", "doInBackground: TELEGRAPH $link")
                    ExTele().execute(link)
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
            return null
        }
    }

    private inner class ExTele : AsyncTask<String?, Void?, Void?>() {
         override fun doInBackground(vararg strings: String?): Void? {
            val doc: Document
            val u = strings[0]
            Log.i("TAG", "Scraping url  $u")
            try {
                doc = Jsoup.connect(u).get()
                val main = doc.select("div.mainStory-normal")
                val title = main.select("h1").first().text()
                val author = main.select("div.author-name").first().text()
                val date = main.select("div.published-infor").first().select("li").first().text().split("Published").toTypedArray()[1]
                val imgurl = main.select("div.Storyimage").first().select("img").first().absUrl("src")
                val builder = StringBuilder()
                builder.append(main.select("div.padiingDetails").first().select("p").text())
                ad1(title, imgurl, builder.toString(), author, date)
                Log.d("EXTELE", "DATA FROM TELEGRAPH $imgurl$builder")
            } catch (e: IOException) {
                e.printStackTrace()
            }
            return null
        }

        override fun onPostExecute(aVoid: Void?) {
            super.onPostExecute(aVoid)
            newsAdapter1!!.notifyDataSetChanged()
        }
    }

    fun ad(ti: String?, imgurl: String?, cont: String?, auth: String?, tida: String?) {
        data = NewsData(ti, "desc", tida, auth, imgurl, cont, "first", 0)
        newsDataList!!.add(data!!)
    }

    fun ad1(ti: String?, imgurl: String?, cont: String?, auth: String?, tida: String?) {
        data1 = NewsData(ti, "desc", tida, auth, imgurl, cont, "first", 1)
        newsDataList1!!.add(data1!!)
    }

    override fun onPostResume() {
        super.onPostResume()
        bottomNavigationView!!.selectedItemId = R.id.page_2
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    companion object {
        private const val APP_ID = "app40514ed2b6b44d8ab8"
        private const val ZONE_IDS = "vz4835d55a49e64ca7bc"
    }
}